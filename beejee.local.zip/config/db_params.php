<?php

return [
	'host' => 'localhost',
	'dbname' => 'beejee',
	'user' => 'root',
	'password' => '',
];