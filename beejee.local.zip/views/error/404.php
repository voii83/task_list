<?php include ROOT . '/views/layouts/header.php'; ?>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <h2>Такой страницы не существует</h2>
        </div>
    </div>
</div>
<?php include ROOT . '/views/layouts/footer.php'; ?>